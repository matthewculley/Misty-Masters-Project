package lab2;

import java.util.Set;

/** 
 *   Ledger defines for each user the balance at a given time
     in the ledger model of bitcoins
     and contains methods for checking and updating the ledger
     including processing a transaction
 */

public class Ledger extends UserAmount{


    /** 
     *
     *  Task 1: Fill in the method checkUserAmountDeductable
     *          You need to replace the dummy value true by the correct calculation
     *
     * Check all items in amountToCheckForDeduction can be deducted from the current one
     *
     *   amountToCheckForDeduction is usually obtained
     *   from a list of inputs of a transaction
     *
     * Checking that a TransactionOutputList  can be deducted will be later done
     *  by first converting that TransactionOutputList into a
     *  UserAmount and then using this method
     *
     * A naive check would just check whether each entry of a outputlist of a Transaction 
     *   can be deducted
     *
     * But there could be an output for the same user Alice of say 10 units twice
     *   where there are not enough funds to deduct it twice but enough
     *   funds to deduct it once
     * The naive check would succeed, but after converting the output list of a Transaction
     *  to UserAmount we obtain that for Alice 20 units have to be deducted
     *  so the deduction of the UserAmount created fails.
     *
     * One could try for checking that one should actually deduct each entry in sequence
     *   but then one has to backtrack again.
     * Converting the TransactionOutputList into a UserAmount
     *   is a better approach since the outputlist of a Transaction
     *   is usually much smaller than the main Ledger.
     * 
     *
     */    

    public boolean checkUserAmountDeductable(UserAmount userAmountCheck){
    	
    	//check all items in userAmountCheck can be deducted from the ledger  	
      	
    	Set<String> users = userAmountCheck.getUsers(); //users in userAmountCheck
    	for (String  user : users) {
    		//if user in the ledger
    		if (this.getUsers().contains(user)) {
    			//if the balance is not great enough make false
    			if (this.getBalance(user) < userAmountCheck.getBalance(user)) {
    				return false; //if the user does not have the neccessary balance
    			}
    		} else {
    			// if the user is not in the ledger
    			return false;
    		}
		}
		return true;
    }


    /** 
     *
     *  Task 2: Fill in the method checkEntryListDeductable 
     *          You need to replace the dummy value true by the correct calculation
     *
     *  It checks that an EntryList (which will be inputs of a transactions)
     *     can be deducted from Ledger
     *
     *   done by first converting the EntryList into a UserAmount
     *     and then checking that the resulting UserAmount can be deducted.
     *   
     */    


    public boolean checkEntryListDeductable(EntryList txel){
		return this.checkUserAmountDeductable(new UserAmount(txel));
    }

    /** 
     *  Task 3: Fill in the methods subtractEntryList and addEntryList.
     *
     *   Subtract an EntryList (txel, usually transaction inputs) from the ledger 
     *
     *   requires that the list to be deducted is deductable.
     *   
     */    
    

    public void subtractEntryList(EntryList txel){
    	if (checkEntryListDeductable(txel)) {
    		for (Entry entry : txel.toList()) {
    			this.subtractBalance(entry.getUser(), entry.getAmount());
    		}
    	}
    }




    /** 
     * Add an EntryList (txel, usually transaction outputs) to the current ledger
     *
     */    

    public void addEntryList(EntryList txel){
		for (Entry entry : txel.toList()) {
			this.addBalance(entry.getUser(), entry.getAmount());
		}
    }


    /** 
     *
     *  Task 4: Fill in the method checkTransactionValid
     *          You need to replace the dummy value true by the correct calculation
     *
     * Check a transaction is valid:
     *    the sum of outputs is less than or equal the sum of inputs
     *    and the inputs can be deducted from the ledger.
     *
     */    
    
    public boolean checkTransactionValid(Transaction tx){
    	return tx.checkTransactionAmountsValid();
    }

    /** 
     *
     *  Task 5: Fill in the method processTransaction
     *
     * Process a transaction
     *    by first deducting all the inputs
     *    and then adding all the outputs.
     *
     */    
    

    public void processTransaction(Transaction tx){
    	if (checkTransactionValid(tx)) {
    		subtractEntryList(tx.toInputs());
    		addEntryList(tx.toOutputs());
    	}
    }



    /** 
     *  Task 6: Fill in the testcases as described in the labsheet
     *    
     * Testcase
     */
    
    public static void test() {
    	Ledger l = new Ledger();
    	
    	l.addAccount("Alice", 0);
    	l.addAccount("Bob", 0);
    	l.addAccount("Carol", 0);
    	l.addAccount("David", 0);
    	
    	l.setBalance("Alice", 20);
    	
    	l.setBalance("Bob", 15);
    	
    	l.addBalance("Alice", 5);
  
    	l.subtractBalance("Bob", 5);
    	
    	l.print();
    	
    	System.out.println();
    	EntryList txel1 = new EntryList("Alice", 15, "Bob", 10);
    	System.out.println("txel1, dedctable: " + l.checkEntryListDeductable(txel1));
    	
    	EntryList txel2 = new EntryList("Alice", 15, "Alice", 15, "Bob", 5);
    	System.out.println("txel2, dedctable: " + l.checkEntryListDeductable(txel2));
    	
    	System.out.println("\nDeduct txel1 from the ledger");
    	txel1.print();
    	l.subtractEntryList(txel1);
    	l.print();

    	
    	System.out.println("\nadd txel2 to the ledger");
    	txel2.print();
    	l.addEntryList(txel2);
    	l.print();

    	EntryList tx1Inputs = new EntryList("Alice", 45);
    	EntryList tx1Outputs = new EntryList("Bob", 5, "Carol", 20);
    	Transaction tx1 = new Transaction(tx1Inputs, tx1Outputs);
    	System.out.println("\ntx1, valid: " + tx1.checkTransactionAmountsValid());
    	
    	EntryList tx2Inputs = new EntryList("Alice", 20);
    	EntryList tx2Outputs = new EntryList("Bob", 5, "Carol", 20);
    	Transaction tx2 = new Transaction(tx2Inputs, tx2Outputs);
    	System.out.println("tx2, valid: " + tx2.checkTransactionAmountsValid());
    	
    	EntryList tx3Inputs = new EntryList("Alice", 25);
    	EntryList tx3Outputs = new EntryList("Bob", 10, "Carol", 15);
    	Transaction tx3 = new Transaction(tx3Inputs, tx3Outputs);
    	System.out.println("tx3, valid: " + tx3.checkTransactionAmountsValid());

    	System.out.println("\nBefore tx3:");
    	l.print();    	
    	System.out.println("-----------------------\nAfter tx3:");
    	l.processTransaction(tx3);
    	l.print();
    	
    	EntryList tx4Inputs = new EntryList("Alice", 5, "Alice", 5);
    	EntryList tx4Outputs = new EntryList("Bob", 10);
    	Transaction tx4 = new Transaction(tx4Inputs, tx4Outputs);
    	
    	System.out.println("\nBefore tx4:");
    	l.print();   
    	System.out.println("-----------------------\nAfter tx4:");
    	l.processTransaction(tx4);
    	l.print();

    }
    
    /** 
     * main function running test cases
     */            

    public static void main(String[] args) {
    	Ledger.test();	
    }
}
